	  <link href="/css/sb-admin-2.css" rel="stylesheet">
	  <!-- Begin Page Content -->
      <div class="container-fluid">
			<div class="row">
				<div class="col-lg-6">
                <div class="p-5">
				{{$body}}
                </div>
              </div>
            </div>
      </div>  
	

  
  